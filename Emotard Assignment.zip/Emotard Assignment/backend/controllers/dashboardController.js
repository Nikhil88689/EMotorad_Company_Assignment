// backend/controllers/dashboardController.js
exports.getDashboardData = (req, res) => {
    // req.user is set by the auth middleware after verifying the JWT.
    res.json({ msg: 'Welcome to your dashboard!', userId: req.user.userId });
  };
  