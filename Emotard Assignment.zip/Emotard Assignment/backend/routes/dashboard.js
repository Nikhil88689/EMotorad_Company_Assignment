// routes/dashboard.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { getDashboardData } = require('../controllers/dashboardController');

// Protected dashboard route

router.get('/', auth, getDashboardData);

router.get('/', auth, (req, res) => {
  res.json({ msg: 'Welcome to your dashboard!', userId: req.user.userId });
});

module.exports = router;
