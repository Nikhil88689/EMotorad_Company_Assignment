import React, { useState, useEffect } from 'react';
import { styled, useTheme } from '@mui/material/styles';
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CssBaseline,
  Box,
  Grid,
  Card,
  CardContent,
  Paper,
  Button,
  Container,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import DashboardIcon from '@mui/icons-material/Dashboard';
import BarChartIcon from '@mui/icons-material/BarChart';
import SettingsIcon from '@mui/icons-material/Settings';
import { DataGrid } from '@mui/x-data-grid';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const drawerWidth = 240;

const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: `-${drawerWidth}px`,
    ...(open && {
      transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 0,
    }),
  })
);

// This function simulates fetching data from an API.
function simulateDashboardData() {
  // Generate random metrics
  const metrics = [
    { title: 'Total Sales', value: `$${(Math.random() * 20000).toFixed(0)}` },
    { title: 'Total Revenue', value: `$${(Math.random() * 100000).toFixed(0)}` },
    { title: 'Active Users', value: `${Math.floor(Math.random() * 5000)}` },
    { title: 'New Orders', value: `${Math.floor(Math.random() * 500)}` },
  ];

  // Generate random chart data for 7 months
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul'];
  const chartData = months.map(month => ({
    month,
    sales: Math.floor(Math.random() * 500),
    revenue: Math.floor(Math.random() * 1000),
  }));

  // Generate random table rows
  const rows = Array.from({ length: 5 }, (_, id) => ({
    id: id + 1,
    orderId: `A00${id + 1}`,
    customer: ['John Doe', 'Jane Smith', 'Bob Johnson', 'Alice Brown', 'Michael Lee'][id],
    amount: Math.floor(Math.random() * 200) + 50,
    status: ['Completed', 'Pending', 'Cancelled'][Math.floor(Math.random() * 3)],
  }));

  return { metrics, chartData, rows };
}

export default function Dashboard() {
  const theme = useTheme();
  const [open, setOpen] = useState(true);
  const [metrics, setMetrics] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [rows, setRows] = useState([]);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleDrawerToggle = () => {
    setOpen(!open);
  };

  // Function to update dashboard data dynamically.
  const updateDashboardData = () => {
    const data = simulateDashboardData();
    setMetrics(data.metrics);
    setChartData(data.chartData);
    setRows(data.rows);
  };

  const fetchDashboard = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/dashboard', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setMessage(res.data.msg);
    } catch (err) {
      setMessage('Failed to fetch dashboard data');
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  useEffect(() => {
    // Fetch initial data.
    updateDashboardData();
    fetchDashboard();
    // Update data every 10 seconds.
    const interval = setInterval(updateDashboardData, 10000);
    return () => clearInterval(interval);
  }, []);

  const columns = [
    { field: 'orderId', headerName: 'Order ID', width: 120 },
    { field: 'customer', headerName: 'Customer', width: 150 },
    { field: 'amount', headerName: 'Amount ($)', width: 130, type: 'number' },
    { field: 'status', headerName: 'Status', width: 130 },
  ];

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      {/* AppBar */}
      <AppBar position="fixed" sx={{ zIndex: theme.zIndex.drawer + 1 }}>
        <Toolbar>
          <IconButton color="inherit" edge="start" onClick={handleDrawerToggle} sx={{ mr: 2 }}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div">
            Dynamic Analytics
          </Typography>
          <Button color="inherit" onClick={logout} sx={{ marginLeft: 'auto' }}>
            Logout
          </Button>
        </Toolbar>
      </AppBar>
      {/* Sidebar Drawer */}
      <Drawer
        variant="persistent"
        anchor="left"
        open={open}
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': { width: drawerWidth, boxSizing: 'border-box' },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: 'auto' }}>
          <List>
            {['Dashboard', 'Analytics', 'Settings'].map((text, index) => (
              <ListItem button key={text}>
                <ListItemIcon>
                  {index === 0 ? <DashboardIcon /> : index === 1 ? <BarChartIcon /> : <SettingsIcon />}
                </ListItemIcon>
                <ListItemText primary={text} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
      {/* Main Content */}
      <Main open={open}>
        <Toolbar />
        <Grid container spacing={3}>
          {/* Metric Cards */}
          {metrics.map((metric, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Card>
                <CardContent>
                  <Typography variant="h6" color="textSecondary" gutterBottom>
                    {metric.title}
                  </Typography>
                  <Typography variant="h4">{metric.value}</Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
          {/* Chart Section */}
          <Grid item xs={12} md={8}>
            <Paper elevation={3} sx={{ padding: 2 }}>
              <Typography variant="h6" gutterBottom>
                Monthly Sales & Revenue
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="sales" stroke="#8884d8" activeDot={{ r: 8 }} />
                  <Line type="monotone" dataKey="revenue" stroke="#82ca9d" />
                </LineChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>
          {/* Data Grid Section */}
          <Grid item xs={12}>
            <Paper elevation={3} sx={{ height: 400, padding: 2 }}>
              <Typography variant="h6" gutterBottom>
                Recent Orders
              </Typography>
              <DataGrid rows={rows} columns={columns} pageSize={5} rowsPerPageOptions={[5]} />
            </Paper>
          </Grid>
        </Grid>
        <Container>
          <Typography variant="body1" sx={{ mt: 2 }}>{message}</Typography>
        </Container>
      </Main>
    </Box>
  );
}