// components/Register.js
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Container, TextField, Button, Typography, Box } from '@mui/material';
import axios from 'axios';

export default function Register() {
  const [formData, setFormData] = useState({ username: '', email: '', password: '' });
  const [errorMsg, setErrorMsg] = useState('');
  const navigate = useNavigate();

  const { username, email, password } = formData;

  const onChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/auth/register', { username, email, password });
      localStorage.setItem('token', res.data.token);
      navigate('/dashboard');
    } catch (err) {
      setErrorMsg(err.response?.data?.msg || 'Registration failed');
    }
  };

  return (
    <Container maxWidth="sm">
      <Box sx={{ mt: 8, textAlign: 'center' }}>
        <Typography variant="h4">Register</Typography>
        {errorMsg && <Typography color="error">{errorMsg}</Typography>}
        <Box component="form" onSubmit={onSubmit} sx={{ mt: 2 }}>
          <TextField fullWidth required label="Username" name="username" value={username} onChange={onChange} margin="normal" />
          <TextField fullWidth required label="Email" name="email" value={email} onChange={onChange} margin="normal" />
          <TextField fullWidth required label="Password" name="password" type="password" value={password} onChange={onChange} margin="normal" />
          <Button type="submit" variant="contained" fullWidth sx={{ mt: 3 }}>Register</Button>
          <Typography variant="body2" sx={{ mt: 2 }}>
            Already have an account? <Link to="/login">Login</Link>
          </Typography>
        </Box>
      </Box>
    </Container>
  );
}
